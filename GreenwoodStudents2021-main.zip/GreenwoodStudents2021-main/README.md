

Courses are organized under Jupyter notebooks

Each chapter contains: Course + Exercises + Solutions

# Course Structure
1. Variables and Data types
2. Boolean operators
3. Scoop on Lists/Tuples/Dictionnaries

